#!/bin/bash

# Update package list
apt-get update

# Install nginx
apt-get install -y nginx
