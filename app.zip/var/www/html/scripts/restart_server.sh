#!/bin/bash

# Restart nginx
systemctl restart nginx
